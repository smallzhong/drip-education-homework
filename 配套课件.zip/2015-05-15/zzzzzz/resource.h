//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by z.rc
//
#define IDD_DIALOG_MAIN                 101
#define IDC_EDIT_RC                     1001
#define IDC_EDIT_B1                     1002
#define IDC_EDIT_B2                     1003
#define IDC_EDIT_B3                     1004
#define IDC_EDIT_C1                     1005
#define IDC_EDIT_C2                     1006
#define IDC_EDIT_C3                     1007
#define IDC_EDIT_C4                     1008
#define IDC_BUTTON_BEGIN                1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
